package boleto;

public class Boleto {

    private String Codigo_Barras;//
    private Fecha Entrada_fecha;
    private Tiempo Entrada_Hora;
    private Fecha Salida_Fecha;
    private Tiempo Salida_Hora;


    public Boleto(){

        this.Codigo_Barras="000000";
        Fecha fecha=new Fecha();
    }

    public void set


    
}
