package boleto;





public class Boleto  {

    private String Codigo_Barras;
    private Fecha Entrada_fecha;
    private Tiempo Entrada_Hora;
    private Fecha Salida_Fecha;
    private Tiempo Salida_Hora;

    //metodo constructor;
    Tiempo hora=new Tiempo();
    public Boleto(){

        this.Codigo_Barras="000000";
        
        this.Entrada_fecha=new Fecha();
        this.Entrada_Hora=new Tiempo();
        this.Salida_Fecha=new Fecha();
        this.Salida_Hora=new Tiempo();
    }

    public void setCodigoBarras(String Codigo_Barras){

        this.Codigo_Barras=Codigo_Barras;

    }

    public String getCodigoBarras(){

        return Codigo_Barras;
    }

    public void setEntradaFecha(int dia,int mes,int anio){

        Entrada_fecha.setDia(dia);
        Entrada_fecha.setMes(mes);
        Entrada_fecha.setAnio(anio);

        //fecha.setDia(dia);
        //fecha.setMes(mes);
        //fecha.setAnio(anio);
    }

    public Fecha getEntradaFecha(){

        return Entrada_fecha;
    }

    public void setEntradaHora(int hora,int minuto,int segundo){
        
        
        Entrada_Hora.setHora(hora);
        Entrada_Hora.setMinuto(minuto);
        Entrada_Hora.setSegundo(segundo);

    }

    public Tiempo getEntradaHora(){

        return Entrada_Hora;
    }


    public void setSalidaFecha(int dia,int mes,int anio){

        Salida_Fecha.setDia(dia);
        Salida_Fecha.setMes(mes);
        Salida_Fecha.setAnio(anio);
    }

    public Fecha getSalidaFecha(){

        return Salida_Fecha;
    }

    public void setSalidaHora(int hora,int minuto,int segundo){

        Salida_Hora.setHora(hora);
        Salida_Hora.setMinuto(minuto);
        Salida_Hora.setSegundo(segundo);
    }

    public Tiempo getSalidaHora(){

        return Salida_Hora;
    }



    public static void main(String[] args){


        Boleto entrada=new Boleto();

        entrada.setEntradaHora(3, 04, 34);
        entrada.setSalidaFecha(3, 7, 2003);
        entrada.setSalidaHora(4, 57, 23);

        Fecha Entrada_Fecha=entrada.getEntradaFecha();
        Tiempo Entrada_Tiempo=entrada.getEntradaHora();
        Fecha Salida_Fecha=entrada.getSalidaFecha();
        Tiempo Salida_Hora=entrada.getSalidaHora();

        System.out.println("la fecha de entrada es: "+ Entrada_Fecha.getDia()+"/"+Entrada_Fecha.getMes()+"/"+Entrada_Fecha.getAnio());
        System.out.println("la hora de intrada es: "+Entrada_Tiempo.getHora()+":"+Entrada_Tiempo.getMinuto()+":"+Entrada_Tiempo.getSegundo());

        System.out.println("la fecha de salida es: "+Salida_Fecha.getDia()+"/"+Salida_Fecha.getMes()+"/"+Salida_Fecha.getAnio());
        System.out.println("la hora de salida fue: "+Salida_Hora.getHora()+":"+Salida_Hora.getMinuto()+":"+Salida_Hora.getSegundo());


    }
    
}
